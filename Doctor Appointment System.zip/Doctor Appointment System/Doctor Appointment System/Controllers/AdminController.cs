﻿using Microsoft.AspNetCore.Mvc;
using Doctor_Appointment_System.Data;
using Doctor_Appointment_System.Models;


namespace Doctor_Appointment_System.Controllers
{
    [ApiController]
    [Route("Api/[Controller]")]
    public class AdminController : Controller
    {


        private readonly AppDbContext dbContext;

        public AdminController(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost("Create-Doctor")]
        public IActionResult CreateDoctor([FromBody] Doctor doctor)
        {
            if (doctor == null)
            {
                return BadRequest("Doctor data is required");
            }
          
            dbContext.Doctors.Add(doctor);
            dbContext.SaveChanges();

            return Ok(new{message="Doctor Added Successfully"});
        }



        public IActionResult Index()
        {
            return View();
        }


        //
    }
}
