﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Net;

namespace Doctor_Appointment_System.Models
{
    public class Doctor
    {

        [Key]

        [Required]
        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string image { get; set; }
        public string speciality { get; set; }
        public string degree { get; set; }
        public string experience { get; set; }
        public string about { get; set; }
        public bool available { get; set; }
        public decimal fees { get; set; } // Use decimal for currency
        public string address { get; set; } // Strongly typed address
        public DateTime Date { get; set; }
        [NotMapped]
        public Dictionary<DateTime, List<string>> SlotsBooked { get; set; } = new Dictionary<DateTime, List<string>>();
    }
}
