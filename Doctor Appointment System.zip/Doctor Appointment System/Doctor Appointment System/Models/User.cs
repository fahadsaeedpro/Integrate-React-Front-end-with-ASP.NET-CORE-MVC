﻿using System.ComponentModel.DataAnnotations;

namespace Doctor_Appointment_System.Models
{
    public class User
    {

        [Key]

        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string image { get; set; }
        
        public string address { get; set; } // Strongly typed address
        public string  gender { get; set; }
        public string dob { get; set; }
        public string phone  { get; set; }

    }
}
